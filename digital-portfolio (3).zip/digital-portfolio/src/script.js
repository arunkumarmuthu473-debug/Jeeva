// Display your name dynamically

document.getElementById("name").textContent = "MUTHULAKSHMI";